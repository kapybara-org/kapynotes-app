# Lisbon trip budget
## Flights for two
flights = 412 eur
daily * 7