Weekly review
a second note that wants the same file name