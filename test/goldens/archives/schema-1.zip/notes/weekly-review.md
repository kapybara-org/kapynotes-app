# Weekly review
something **bold** and something *italic*
literals: \*star\* \_score\_ #hash \`tick\` \[bracket]