Réunion hebdo
notes en français